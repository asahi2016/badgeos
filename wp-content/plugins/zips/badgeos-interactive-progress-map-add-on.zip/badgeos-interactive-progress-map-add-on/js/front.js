(function($){
    $("#slickCarousel").slick({
        dots: true,
        speed: 500,
        autoplay : true
    });
})(jQuery);
