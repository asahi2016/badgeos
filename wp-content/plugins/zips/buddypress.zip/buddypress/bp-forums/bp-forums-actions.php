<?php
/**
 * BuddyPress Forums Actions.
 *
 * @package BuddyPress
 * @subpackage ForumsActions
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
