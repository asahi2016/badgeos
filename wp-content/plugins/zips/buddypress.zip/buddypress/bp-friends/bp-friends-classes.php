<?php
/**
 * BuddyPress Friends Classes.
 *
 * @package BuddyPress
 * @subpackage FriendsClasses
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

require dirname(__FILE__) . '/classes/class-bp-friends-friendship.php';
